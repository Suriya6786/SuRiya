const cmdIcons = {
    dotIcon: 'https://cdn.discordapp.com/emojis/915658913850998794.gif',
};

module.exports = cmdIcons;